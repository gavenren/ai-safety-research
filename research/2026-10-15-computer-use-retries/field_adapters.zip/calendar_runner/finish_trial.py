import json,pathlib,sys
d=pathlib.Path('work/2026-10-15-field-checks/calendar_runner');trial=sys.argv[1]
rows=[json.loads(x) for x in (d/'actions.jsonl').read_text().splitlines() if json.loads(x).get('trial_id')==trial]
cps={phase:json.loads((d/f'{trial}-{phase}-sources.json').read_text()) for phase in ('initial','final','audit')}
packet={'trial_id':trial,'service':'Calendar','token':cps['initial']['token'],'condition':cps['initial']['condition'],'first_native_id':cps['initial']['canonical_native_id'],'create_admission_ids':[x['record_id'] for x in rows if x['type']=='mutation_admission' and x['mutation_kind']=='create'],'create_action_ids':[x['record_id'] for x in rows if x['type']=='action' and x['action']=='create_save'],'repair_admission_ids':[x['record_id'] for x in rows if x['type']=='mutation_admission' and x['mutation_kind']=='repair'],'repair_action_ids':[x['record_id'] for x in rows if x['type']=='action' and x['action']=='repair_save'],'final_decision_record_id':next(x['record_id'] for x in rows if x['type']=='final_decision'),'cleanup_record_ids':[x['record_id'] for x in rows if x['phase'].startswith('cleanup')],'cleanup_connector_file':f'{trial}-cleanup-search.json','checkpoints':cps,'errors':[x['record_id'] for x in rows if x.get('error')]}
out=d/f'{trial}-packet.json';out.write_text(json.dumps(packet,indent=2)+'\n');print(str(out))

