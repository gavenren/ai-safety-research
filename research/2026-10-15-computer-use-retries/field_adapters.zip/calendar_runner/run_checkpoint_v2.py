#!/usr/bin/env python3
"""Live checkpoint adapter. Derives fields from saved raw evidence and calls frozen checker.
No network access and no website mutations. The browser runner still makes each decision.
"""
import argparse, base64, datetime, importlib.util, json, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument('--trial',required=True);ap.add_argument('--phase',required=True)
ap.add_argument('--checker',required=True);ap.add_argument('--dir',required=True)
args=ap.parse_args(); d=pathlib.Path(args.dir)
spec=importlib.util.spec_from_file_location('frozen_fieldcheck',args.checker)
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
p=d/f'{args.trial}-{args.phase}-sources.json';cp=json.loads(p.read_text())
rows=[json.loads(x) for x in (d/'actions.jsonl').read_text().splitlines()]
byid={x['record_id']:x for x in rows}
native=byid[cp['native_state_id']];dom=byid[cp['native_value_read_id']]
covered=byid[cp['covered_state_id']];s=native['state']
def one(pattern,text=s):
 m=re.search(pattern,text,re.M);return m.group(1) if m else c.MISSING
def native_id(url):
 if '/eventedit/' not in url:return None
 raw=url.split('/eventedit/',1)[1].split('?',1)[0]
 try:return base64.urlsafe_b64decode(raw+'='*(-len(raw)%4)).decode().split(' ',1)[0]
 except Exception:return None
def date_value(name):
 value=one(r'- textbox "'+name+r'": ([^\n]+)')
 if value is c.MISSING:return c.MISSING
 try:return datetime.datetime.strptime(value,'%b %d, %Y').date().isoformat()
 except ValueError:return value
ui={}
title=one(r'- textbox "Title":\n(?:    - /placeholder:[^\n]+\n)?    - text: ([^\n]+)')
if title is not c.MISSING:ui['title']=title
for key,name in [('start_date','Start date'),('end_date','End date')]:
 value=date_value(name)
 if value is not c.MISSING:ui[key]=value
if '- checkbox "All day" [checked]' in s:ui['all_day']=True
elif re.search(r'- checkbox "All day"(?: \[active\])?\n',s):ui['all_day']=False
for key,name in [('availability','Show as'),('visibility','Visibility'),('recurrence','Recurrence')]:
 value=one(r'- combobox "'+name+r'"(?: \[active\])?:\n[ ]+- generic:? "?([^"\n]+)"?')
 if value is not c.MISSING:ui[key]=value
# Explicit empty native sections, not absence of a required section.
if re.search(r'- tabpanel "Guests":\n    - combobox "Guests"\n    - group "Guest permissions":',s):ui['guests']=[]
if re.search(r'^    - combobox "Add location"\s*$',s,re.M):ui['location']=''
if '- button "Add Google Meet video conferencing":' in s:ui['conference']=False
if re.search(r'^    - list "Notifications"\n    - button "Add notification":',s,re.M):ui['reminders']=[]
v=dom.get('value',{})
if v.get('tag')=='DIV' and v.get('role')=='textbox' and v.get('contenteditable')=='true' and type(v.get('innerText')) is str:
 ui['description']=v['innerText']
searchfile=f'{args.trial}-{args.phase}-search.json';readfile=f'{args.trial}-{args.phase}-read.json'
search=json.loads((d/searchfile).read_text());read=json.loads((d/readfile).read_text())
sr=search['result'];rr=read['result'];ev=rr.get('structuredContent',{})
event_ids=[x['id'] for x in sr.get('structuredContent',{}).get('events',[])]
idsource=json.loads((d/f'{args.trial}-initial-sources.json').read_text())
first=native_id(idsource['native_id']);current=native_id(cp['native_id'])
fields=c.calendar_fields(cp['token'],ui,ev)
actions=[x for x in rows if x.get('trial_id')==args.trial and x.get('type')=='action' and x.get('action') in ('create_save','repair_save')]
latest=actions[-1]
native_ready=('- heading "Event edit page" [level=1]' in s and '- textbox "Title":' in s and '- textbox "Start date":' in s and '- textbox "End date":' in s and '- checkbox "All day"' in s and '- textbox "Description"' in s and '- progressbar' not in s and '- dialog' not in s)
scope=(('q='+cp['token']) in covered['url'] and 'start=20261001' in covered['url'] and 'end=20261031' in covered['url'])
cover_ready=bool(re.search(r'heading "Search results\. (?:1 event found|No events found)\."',covered['state'])) and '- progressbar' not in covered['state'] and 'Searching' not in covered['state']
search_complete=(sr.get('isError') is False and sr.get('structuredContent',{}).get('next_page_token','absent') is None)
service_ready=(rr.get('isError') is False and search_complete)
facts=dict(first_id=first,ui_id=current,service_id=ev.get('id',c.MISSING),operation_ids=event_ids,native_ready=native_ready,native_fresh=native['start_utc']>latest['end_utc'],service_ready=service_ready,service_fresh=read['start_utc']>latest['end_utc'] and search['start_utc']>latest['end_utc'],coverage_ready=cover_ready,coverage_fresh=covered['start_utc']>latest['end_utc'],scope_covered=scope,edit_pending=False,needs_service=True)
out=c.check_record(fields,**facts)
now=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
record=dict(record_id='FCCAL-'+str(len(rows)+1).zfill(5),trial_id=args.trial,token=cp['token'],service='Calendar',type='field_check',phase=args.phase,tab_role='observer',start_utc=now,end_utc=now,raw_observed_values={'native_ui':ui,'native_description_dom':v,'connector':ev},per_field_checks=out['checks'],overall=out['status'],facts=facts,source_ids={'native_state_id':cp['native_state_id'],'native_value_read_id':cp['native_value_read_id'],'covered_state_id':cp['covered_state_id'],'covered_identity_record_ids':cp['covered_identity_record_ids'],'last_save_action_id':latest['record_id']},connector_files=[searchfile,readfile],checker_path=args.checker,checker_use='live_before_next_action')
(d/'actions.jsonl').open('a').write(json.dumps(record)+'\n')
cp['connector_files']=[searchfile,readfile];cp['field_check_record_id']=record['record_id'];cp['canonical_native_id']=current
p.write_text(json.dumps(cp,indent=2)+'\n')
(d/f'{args.trial}-{args.phase}-check.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'record_id':record['record_id'],'overall':out['status'],'nonmatches':{k:v for k,v in out['checks'].items() if v['status']!='MATCH'},'sources':record['source_ids'],'canonical_native_id':current,'elapsed_from_save_admission':(datetime.datetime.fromisoformat(now.replace('Z','+00:00'))-datetime.datetime.fromisoformat(next(x for x in rows if x.get('trial_id')==args.trial and x.get('type')=='mutation_admission' and x.get('mutation_kind')=='create')['start_utc'].replace('Z','+00:00'))).total_seconds()}))

